A Pen created at CodePen.io. You can find this one at http://codepen.io/colinkeany/pen/XJOvXz.

 Simple effect for a profile card. Hovering on the container flips the avatar to reveal an animated gif.